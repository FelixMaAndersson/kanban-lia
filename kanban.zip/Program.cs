using kanban_lia.Endpoints.Boards;
using kanban_lia.Endpoints.Columns;
using kanban_lia.Endpoints.Placements;
using kanban_lia.Hubs;
using kanban_lia.Infrastructure.Database;
using kanban_lia.Infrastructure.JsonConverters;
using kanban_lia.Infrastructure.Messaging;
using kanban_lia.Infrastructure.Repositories.Boards;
using kanban_lia.Infrastructure.Repositories.Columns;
using kanban_lia.Infrastructure.Repositories.Outbox;
using kanban_lia.Infrastructure.Repositories.Placements;
using kanban_lia.Models.Domain.Exceptions;
using kanban_lia.Services.Boards;
using kanban_lia.Services.Boards.Exceptions;
using kanban_lia.Services.Columns;
using kanban_lia.Services.Columns.Exceptions;
using kanban_lia.Services.IntegrationEvents;
using kanban_lia.Services.Placements;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<DbConnectionFactory>();

builder.Services.AddScoped<IBoardRepository, BoardRepository>();
builder.Services.AddScoped<IColumnRepository, ColumnRepository>();
builder.Services.AddScoped<IPlacementRepository, PlacementRepository>();
builder.Services.AddScoped<IColumnEdgeRepository, ColumnEdgeRepository>();

builder.Services.AddScoped<IBoardService, BoardService>();
builder.Services.AddScoped<IColumnService, ColumnService>();
builder.Services.AddScoped<IPlacementService, PlacementService>();
builder.Services.AddScoped<IColumnEdgeService, ColumnEdgeService>();

builder.Services.AddScoped<IOutboxRepository, OutboxRepository>();
builder.Services.AddHostedService<OutboxWorker>();
builder.Services.AddSingleton<IIntegrationEventPublisher, RabbitMqIntegrationEventPublisher>();

builder.Services.AddAutoMapper(cfg =>
{
    cfg.AddMaps(typeof(Program).Assembly);
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5173")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials());
});

builder.Services.AddSignalR();

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.Converters.Add(new EntityIdJsonConverter());
    options.SerializerOptions.Converters.Add(new BoardIdJsonConverter());
    options.SerializerOptions.Converters.Add(new ColumnIdJsonConverter());
});

builder.Services.Configure<RabbitMqOptions>(builder.Configuration.GetSection("RabbitMq"));

var app = builder.Build();

app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        var exception = context.Features
            .Get<IExceptionHandlerFeature>()
            ?.Error;

        var statusCode = exception switch
        {
            BoardNotFoundException => StatusCodes.Status404NotFound,
            RootNotFoundException => StatusCodes.Status404NotFound,
            RootAlreadyExistsException => StatusCodes.Status400BadRequest,
            ColumnNotFoundException => StatusCodes.Status404NotFound,
            InvalidDomainException => StatusCodes.Status400BadRequest,
            ArgumentException => StatusCodes.Status400BadRequest,
            SqlException { Number: 547 } => StatusCodes.Status409Conflict,
            SqlException { Number: 2627 } => StatusCodes.Status409Conflict,
            SqlException { Number: 2601 } => StatusCodes.Status409Conflict,
            _ => StatusCodes.Status500InternalServerError
        };

        context.Response.StatusCode = statusCode;

        await Results.Problem(
            statusCode: statusCode,
            title: exception switch
            {
                BoardNotFoundException => "Board could not be found",
                RootNotFoundException => "Root could not be found",
                RootAlreadyExistsException => "Root already exists on this board",
                ColumnNotFoundException => "Column could not be found",
                InvalidDomainException => "Invalid request",
                ArgumentException => "Invalid request parameters",
                SqlException { Number: 547 } => "Operation conflicts with related records",
                SqlException { Number: 2627 } or SqlException { Number: 2601 } => "A record with the same key already exists",
                _ => "Internal server error"
            },
            detail: exception is SqlException
                ? "The operation could not be completed due to a data conflict."
                : exception?.Message
        ).ExecuteAsync(context);
    });
});

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors();

app.MapHub<BoardHub>("/hubs/board");

BoardEndpoints.MapBoardEndpoints(app);
ColumnEndpoints.MapColumnEndpoints(app);
PlacementEndpoints.MapPlacementEndpoints(app);
ColumnEdgeEndpoints.MapColumnEdgeEndpoints(app);

await app.RunAsync();
