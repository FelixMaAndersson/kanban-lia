﻿using AutoMapper;
using kanban_lia.Endpoints.Placements.Requests;
using kanban_lia.Hubs;
using kanban_lia.Infrastructure.Repositories.Columns;
using kanban_lia.Models.Domain.Boards;
using kanban_lia.Models.Domain.Columns;
using kanban_lia.Models.Domain.Placements;
using kanban_lia.Models.Events;
using kanban_lia.Services.Columns.Exceptions;
using kanban_lia.Services.IntegrationEvents.Models;
using kanban_lia.Services.Placements;
using kanban_lia.Services.Placements.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace kanban_lia.Endpoints.Placements;

public static class PlacementEndpoints
{
    /// <summary>
    /// Maps placement-related HTTP endpoints under /api/placements.
    /// </summary>
    /// <remarks>Registers endpoints for creating and retrieving placements: POST /create, GET /get, GET
    /// /board/{boardId}, and GET /column/{columnId}. The POST endpoint validates column write access, resolves
    /// connected source and target columns across boards, computes placement operations, invokes IPlacementService to
    /// create placements, and broadcasts a PlacementCreated event via SignalR. Correlation-Id, Causation-Id, Actor-Id,
    /// and Actor-Type headers are read when present and used for causation/correlation and actor information.</remarks>
    /// <param name="app">The WebApplication on which placement endpoints are configured.</param>
    /// <exception cref="ColumnNotFoundException">Thrown when a required column referenced during endpoint processing cannot be found in the repository.</exception>
    public static void MapPlacementEndpoints(WebApplication app)
    {
        var group = app.MapGroup("/api/placements");
        var logger = app.Services.GetRequiredService<ILoggerFactory>()
            .CreateLogger("PlacementEndpoints");
        
        group.MapPost("/create", async (
            HttpRequest httpRequest,
            [FromBody] CreatePlacementRequest request,
            IPlacementService placementService,
            CancellationToken cancellationToken,
            IColumnRepository columnRepository,
            IColumnEdgeRepository columnEdgeRepository,
            IHubContext<BoardHub> hub) =>
        {
            var entityIds = (request.EntityIds ?? [])
                .Select(id => new EntityId(id))
                .ToList();
            var afterEntityIds = request.AfterEntityIds ?? [];
            var beforeEntityIds = request.BeforeEntityIds ?? [];

            var boardId = new BoardId(request.BoardId);

            var canBeWritten = await columnRepository.CanBeWrittenAsync(new ColumnId(request.ColumnId));

            if (canBeWritten is null)
                throw new ColumnNotFoundException(new ColumnId(request.ColumnId));

            if (!canBeWritten.Value)
                return Results.Problem(
                    statusCode: StatusCodes.Status403Forbidden,
                    title: "Column is not writable",
                    detail: $"Column {request.ColumnId} does not accept new placements.");

            var connectedTargetColumnIds = await GetConnectedColumns(
                new ColumnId(request.ColumnId),
                columnEdgeRepository);

            var connectedTargetColumns = new List<Column>();

            foreach (var columnId in connectedTargetColumnIds)
            {
                var column =
                    await columnRepository.GetByIdAsync(columnId) ?? throw new ColumnNotFoundException(columnId);
                connectedTargetColumns.Add(column);
            }

            var currentPlacements = await placementService.GetCurrentAsync(
                new GetPlacementDto(
                    entityIds,
                    boardId
                )
            );

            var sourceColumnIds = new List<ColumnId>();

            foreach (var placement in currentPlacements)
            {
                var connectedSourceColumns = await GetConnectedColumns(
                    placement.ColumnId,
                    columnEdgeRepository);

                sourceColumnIds.AddRange(connectedSourceColumns);
            }

            sourceColumnIds = [.. sourceColumnIds.Distinct()];

            var sourceColumns = new List<Column>();

            foreach (var sourceColumnId in sourceColumnIds)
            {
                var column = await columnRepository.GetByIdAsync(sourceColumnId);
                if (column is not null)
                {
                    sourceColumns.Add(column);
                }
            }

            var targetGroups = connectedTargetColumns.GroupBy(column => column.BoardId);

            var columnPairs = new List<(ColumnId Target, List<ColumnId> Sources)>();

            foreach (var targetGroup in targetGroups)
            {
                var matchingSources = sourceColumns
                    .Where(source => source.BoardId == targetGroup.Key)
                    .ToList();

                var currentPlacementsOnTargetBoard =
                    await placementService.GetCurrentAsync(
                        new GetPlacementDto(
                            entityIds,
                            targetGroup.Key
                        )
                    );

                var currentSource = matchingSources
                    .FirstOrDefault(source =>
                        currentPlacementsOnTargetBoard.Any(placement =>
                            placement.ColumnId == source.Id));

                var targetColumn = SelectTargetColumn(
                    targetGroup,
                    matchingSources,
                    currentSource);

                columnPairs.Add((
                    Target: targetColumn.Id,
                    Sources: [.. matchingSources.Select(source => source.Id)]
                        ));
            }

            var placementOperations =
                new List<PlacementOperationDto>();

            foreach (var (Target, Sources) in columnPairs)
            {
                var targetColumn =
                    await columnRepository.GetByIdAsync(Target) ?? throw new ColumnNotFoundException(Target);
                var createDto = new CreatePlacementDto(
                    entityIds,
                    targetColumn.BoardId,
                    Target,
                    afterEntityIds.Select(id => new EntityId(id)),
                    beforeEntityIds.Select(id => new EntityId(id))
                );

                var operationDto = new PlacementOperationDto(
                    createDto,
                    Sources
                );

                placementOperations.Add(operationDto);
            }

            var changes = CreatePlacementChanges(columnPairs);

            var (correlationId, causationEventId, actor) = GetEventMetadata(httpRequest);

            await placementService.CreateAsync(placementOperations, correlationId, causationEventId, actor, cancellationToken);

            try
            {
                await hub.Clients.All.SendAsync(
                    "PlacementCreated",
                    new PlacementCreatedEvent(
                        [.. entityIds.Select(id => id.Id)],
                        changes,
                        actor
                    ),
                cancellationToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                // The placements are already committed — a broadcast failure must not
                // turn into a 500; clients will converge on the next fetch.
                logger.LogError(ex,
                    "PlacementCreated broadcast failed after commit for {EntityCount} entities",
                    entityIds.Count);
            }

            return Results.Ok();
        });
#pragma warning restore S107

        group.MapGet("/get", async (
            [FromQuery] Guid[] entityIds,
            [FromQuery] Guid boardId,
            IPlacementService placementService,
            IMapper mapper) =>
        {
            var request = new GetPlacementRequest(
                entityIds,
                boardId);

            var dto = mapper.Map<GetPlacementDto>(request);

            var placement = await placementService.GetCurrentAsync(dto);

            return placement is null
                ? Results.NotFound()
                : Results.Ok(placement);
        });

        group.MapGet("/board/{boardId:guid}", async (
            Guid boardId,
            IPlacementService placementService) =>
        {
            var placements = await placementService.GetCurrentByBoardAsync(
                new BoardId(boardId));

            return Results.Ok(placements);
        });

        group.MapGet("/column/{columnId:guid}", async (
            Guid columnId,
            Guid boardId,
            IPlacementService placementService) =>
        {
            var placements = await placementService.GetCurrentByColumnAsync(
                new ColumnId(columnId),
                new BoardId(boardId));

            return Results.Ok(placements);
        });
    }
    private static async Task<List<ColumnId>> GetConnectedColumns(
        ColumnId columnId,
        IColumnEdgeRepository columnEdgeRepository)
    {
        var fromEdges =
            await columnEdgeRepository.GetByFromColumnIdAsync(columnId);

        var toEdges =
            await columnEdgeRepository.GetByToColumnIdAsync(columnId);

        var connectedColumns = new List<ColumnId>
    {
        columnId
    };

        connectedColumns.AddRange(
            fromEdges.Select(edge => edge.ToColumnId));

        connectedColumns.AddRange(
            toEdges.Select(edge => edge.FromColumnId));

        return [.. connectedColumns.Distinct()];
    }
    private static Column SelectTargetColumn(
    IEnumerable<Column> targetGroup,
    List<Column> matchingSources,
    Column? currentSource)
    {
        var targets = targetGroup.ToList();

        if (matchingSources.Count == 0)
        {
            return targets
                .OrderBy(target => target.Position)
                .First();
        }

        if (targets.Count == 1)
        {
            return targets[0];
        }

        var sourcePosition = currentSource is not null
            ? currentSource.Position
            : matchingSources
                .OrderBy(source => source.Position)
                .First()
                .Position;

        return targets
            .OrderBy(target =>
                Math.Abs(target.Position - sourcePosition))
            .First();
    }

    private static List<PlacementChange> CreatePlacementChanges(
        List<(ColumnId Target, List<ColumnId> Sources)> columnPairs)
    {
        var changes = new List<PlacementChange>();
        foreach (var (Target, Sources) in columnPairs)
        {
            if (Sources.Count == 0)
            {
                changes.Add(new PlacementChange(null, Target.Id));
                continue;
            }

            foreach (var source in Sources)
            {
                changes.Add(new PlacementChange(
                    source.Id,
                    Target.Id
                    ));
            }
        }
        return changes;
    }

    private static (
        Guid CorrelationId,
        Guid? CausationEventId,
        Actor Actor)
        GetEventMetadata(HttpRequest httpRequest)
    {
        Guid correlationId = Guid.NewGuid();
        Guid? causationEventId = null;
        var actorId = "-1";
        var actorType = "";

        if (httpRequest.Headers.TryGetValue(
                "Correlation-Id",
                out var correlationHeader) &&
            Guid.TryParse(correlationHeader, out var parsedCorrelationId))
        {
            correlationId = parsedCorrelationId;
        }

        if (httpRequest.Headers.TryGetValue(
                "Causation-Id",
                out var causationHeader) &&
            Guid.TryParse(causationHeader, out var parsedCausationEventId))
        {
            causationEventId = parsedCausationEventId;
        }

        if (httpRequest.Headers.TryGetValue("Actor-Id", out var actorIdHeader))
        {
            actorId = actorIdHeader.ToString();
        }

        if (httpRequest.Headers.TryGetValue("Actor-Type", out var actorTypeHeader))
        {
            actorType = actorTypeHeader.ToString();
        }

        var actor = new Actor(actorId, actorType);

        return (correlationId, causationEventId, actor);
    }
}