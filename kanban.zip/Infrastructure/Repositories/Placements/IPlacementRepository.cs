﻿using kanban_lia.Models.Domain.Boards;
using kanban_lia.Models.Domain.Columns;
using kanban_lia.Models.Domain.Placements;
using System.Data;

namespace kanban_lia.Infrastructure.Repositories.Placements
{
    public record SortKeyRange(string? Previous, string? Next);
    public enum SortKeyLookup
    {
        Last = 0,
        After = 1,
        Before = 2
    }
    public interface IPlacementRepository
    {
        Task AcquireSortKeyLockAsync(
            IDbTransaction transaction,
            ColumnId columnId,
            CancellationToken cancellationToken);
        Task CreateAsync(IEnumerable<Placement> placements, IDbTransaction transaction);
        Task<IEnumerable<Placement>> GetCurrentAsync(IEnumerable<EntityId> entityIds, BoardId boardId);
        Task<IEnumerable<Placement>> GetCurrentByBoardAsync(BoardId boardId);
        Task<IEnumerable<Placement>> GetCurrentByColumnAsync(ColumnId columnId, BoardId boardId);
        Task<SortKeyRange> GetSortKeyRangeAsync(
            IDbTransaction transaction,
            ColumnId columnId,
            SortKeyLookup lookup,
            EntityId? afterEntityId = null,
            EntityId? beforeEntityId = null,
            CancellationToken cancellationToken = default);
    }
}
