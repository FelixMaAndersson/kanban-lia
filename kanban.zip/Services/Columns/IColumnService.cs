﻿using kanban_lia.Models.Domain.Boards;
using kanban_lia.Models.Domain.Columns;
using kanban_lia.Models.Domain.Columns.DTOs;
using kanban_lia.Services.Columns.DTOs;
using kanban_lia.Services.IntegrationEvents.Models;

namespace kanban_lia.Services.Columns
{
    public interface IColumnService
    {
        Task<ColumnId> CreateAsync(CreateColumnDto dto, Guid correlationId, Actor actor, CancellationToken cancellationToken);
        Task<IEnumerable<ColumnDto>> GetByBoardIdAsync(BoardId boardId);
        Task<ColumnDto?> GetByIdAsync(ColumnId id);
        Task<bool> SetRequestWritableAsync(ColumnId id, bool requestWritable);
        Task<bool> RenameAsync(RenameColumnDto dto);
        Task<bool> DeleteAsync(ColumnId id);
    }
}