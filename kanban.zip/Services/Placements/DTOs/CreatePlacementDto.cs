﻿using kanban_lia.Models.Domain.Boards;
using kanban_lia.Models.Domain.Columns;
using kanban_lia.Models.Domain.Placements;

namespace kanban_lia.Services.Placements.DTOs
{
    public record CreatePlacementDto(
        IEnumerable<EntityId> EntityIds, 
        BoardId BoardId, 
        ColumnId ColumnId, 
        IEnumerable<EntityId> AfterEntityIds, 
        IEnumerable<EntityId> BeforeEntityIds);
}