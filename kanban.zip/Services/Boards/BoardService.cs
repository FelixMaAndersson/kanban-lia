﻿using AutoMapper;

using kanban_lia.Infrastructure.Repositories.Boards;
using kanban_lia.Models.Domain.Boards;
using kanban_lia.Models.Domain.Boards.DTOs;
using kanban_lia.Services.Boards.DTOs;
using kanban_lia.Services.Boards.Exceptions;

namespace kanban_lia.Services.Boards
{
    public class BoardService(
        IBoardRepository repository,
        IMapper mapper) : IBoardService
    {
        private readonly IMapper _mapper = mapper;
        private readonly IBoardRepository _repository = repository;

        public async Task<BoardId> CreateAsync(string title)
        {
            var newBoard = Board.Create(title);

            return await _repository.CreateAsync(newBoard);
        }

        public async Task<BoardDto?> GetByIdAsync(BoardId id)
        {
            var board = await _repository.GetByIdAsync(id);

            if (board is null)
            {
                throw new BoardNotFoundException(id);
            }

            return _mapper.Map<BoardDto>(board);
        }

        public async Task<bool> RenameAsync(RenameBoardDto dto)
        {
            var boardId = dto.Id;

            var board = await _repository.GetByIdAsync(boardId);

            if (board is null)
            {
                throw new BoardNotFoundException(boardId);
            }

            board.Rename(dto.NewTitle);

            var renamed = await _repository.RenameAsync(
                boardId,
                board.Title);

            if (!renamed)
            {
                throw new BoardNotFoundException(boardId);
            }

            return renamed;
        }

        public async Task<bool> AddRootAsync(AddRootDto dto)
        {
            var boardId = dto.BoardId;
            var entityId = dto.EntityId;

            var boardExists = await _repository.BoardExistsAsync(boardId);

            if (!boardExists)
            {
                throw new BoardNotFoundException(boardId);
            }

            var rootExists = await _repository.RootExistsAsync(boardId, entityId);

            if (rootExists)
            {
                throw new RootAlreadyExistsException(entityId);
            }

            var added = await _repository.AddRootAsync(boardId, entityId);

            return added;
        }

        public async Task<bool> RemoveRootAsync(RemoveRootDto dto)
        {
            var boardId = dto.BoardId;
            var entityId = dto.EntityId;

            var boardExists = await _repository.BoardExistsAsync(boardId);

            if (!boardExists)
            {
                throw new BoardNotFoundException(boardId);
            }

            var rootExists = await _repository.RootExistsAsync(boardId, entityId);

            if (!rootExists)
            {
                throw new RootNotFoundException(entityId);
            }

            var removed = await _repository.RemoveRootAsync(boardId, entityId);

            return removed;
        }

        public async Task<bool> DeleteAsync(BoardId id)
        {
            var deleted = await _repository.DeleteAsync(id);

            if (!deleted)
            {
                throw new BoardNotFoundException(id);
            }

            return deleted;
        }
    }
}
